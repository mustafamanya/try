#include "../header/parse.h"
#include <cassert>


int main(int argc, char const *argv[])
{
	char data[512];
	int num = 0;
	char **tokens = NULL;
	
	strcpy(data,"a;b;c");
	tokens = splitString(data,";",&num);
	
	assert(num == 3);
	assert(strcmp(tokens[0],"a") == 0);
	assert(strcmp(tokens[1],"b") == 0);
	assert(strcmp(tokens[2],"c") == 0);

	strcpy(data,"a||b||c");
	tokens = splitString(data,"||",&num);
	
	assert(num == 3);
	assert(strcmp(tokens[0],"a") == 0);
	assert(strcmp(tokens[1],"b") == 0);
	assert(strcmp(tokens[2],"c") == 0);

	strcpy(data,"a&&b&&c");
	tokens = splitString(data,"&&",&num);
	
	assert(num == 3);
	assert(strcmp(tokens[0],"a") == 0);
	assert(strcmp(tokens[1],"b") == 0);
	assert(strcmp(tokens[2],"c") == 0);

	cout << "all tests pass" << endl;
	return 0;
}