#include "../header/parse.h"
#include <cassert>


int main(int argc, char const *argv[])
{
	char data[512];
	strcpy(data,"  abc");
	assert(strcmp(trim(data),"abc") == 0);
	strcpy(data,"  abc  ");
	assert(strcmp(trim(data),"abc") == 0);
	strcpy(data,"  a b c  ");
	assert(strcmp(trim(data),"a b c") == 0);
	strcpy(data,"  a b c 123 ");
	assert(strcmp(trim(data),"a b c 123") == 0);
	cout << "all tests pass" << endl;
	return 0;
}