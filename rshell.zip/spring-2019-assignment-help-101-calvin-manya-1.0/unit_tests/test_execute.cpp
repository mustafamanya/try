#include "../header/execute.h"
#include <cassert>


int main(int argc, char const *argv[])
{
	assert(executeCommand("ls") == true);
	assert(executeCommand("cd ..") == true);
	return 0;
}