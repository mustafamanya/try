# CS 100 RShell

## Project Information
* CS 100 Spring 2019
* Calvin TszFung Ng, 862085322, tng014@ucr.edu
* Mustafa Manya, 861209958, mmany001@ucr.edu


## Introduction
**The purpose of our project is to develop  a shell  called `RShell` that provide an interface for printing command promts, reading  in a line of commands which are transfromed by connectors from standard input, that are  capable of  handling  these  complex commands  by using  connectors like "or" `||` where the next comand excutes only when the first one fails , "and" `&&` where the next command exucutes after the fist one succeeds, and finally `;` where the next command is always going to execute. This is finally  excuted in  fucntions such as  ` fork` , ` execvp`, and ` waitpid`. In short, this  `Rshell`  will  read, execute and return the outputs.**
  






## Digram
![alt text](https://github.com/cs100/spring-2019-assignment-help-101-calvin-manya/blob/master/images/CS100%20Shell.png)





## Classes
* class `Com`: This class represents the command operation. It is mainly declaring types and fucntion we need for the following class. All others classes inherits from this class. It allow user to run the "main.cpp", type username and takes a singular string-type comamnd as iput by the user. It stores a singular user command,which a vector of unique commands specific to the rShell application (ex: touch a) and then parse it in the class `Par`.
* class `Par`: This class represents the parser operation.Inherits from the Command class. It parse the command from class `Com`. This read the class 
* class `Exe`: This class represents the executor operation.Inherits from the Command class. It execute the command and call the `execvp`, through virtual bool executor command. The execute function use fork() to created 2 process which are the parent and child process. In the Child process, the executor call the execvp()function to execute the commands read from the class `Par`. In the parent progess, we call  the waitpid() function to wait for the child finish executing the commands. And, the output will return to the class `Com`.It included all the connectors we need for this assignment which show below. This class have serveral sub-class, which are "And", "Or","Semicolon" class  inherit from this class. It allows the user to rune multiple commands at once.
  * && Connector: if a command is followed by this connector, then the next command executes only if the first one succeeds.
  * || Connector: if a command is followed by this connector, then the next command executes only if the the first one fails                     
  * ; Connector: if a command is followed by this connector, then the next command is always executed.




## Prototypes/Research

* fork()-exec()-wait()- is a well known mechanism to run many process and achive synchronization.

* fork(): creates a new process, upon which kernel suspends the excuting process, creates another process which is a replica of the parent process, resumes both parent and child, runs them concurrently. Fork() system call returns - to the child process and process identifier (PID) of the child process to the parent.
* exec(): Replaces the current process image with a new process image It loads the program into current process spaces and runs it from the entry point.
* waitpid(): is a system call which waits for a specfied process to finish .



```#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
using namespace std;


int main()
{
char* args[3];

string ls= "ls";


args[0]= (char*)ls.c_str();
args[1]=NULL;

pid_t pid= fork();
if (pid== 0)
{
cout<<"child:"<<pid<<endl;
if(execvp(args[0],args)==-1)
{
perror("exec");
}
}
if(pid> 0)
{
wait(0);
cout<<"parent:"<<pid<<endl;
return 0;

}
```
**The fork() function  creates a child process and a parent process. These will run together in parallel. This shows the current processing status. The execvp() returns -1 if we fail.   In this case the child process is running before the parent process because of wait() function and will print out the file in the directories.**  

* Output for prototypes

  * child:0 
  main.cpp README.MD
  
  * parent:36503






## Development and Testing Roadmap
* Implement & test class `Com` by Calvin Ng & Mustafa Manya
* Implement & test class `Par` by Mustafa Manya
* Implement & test "Connctor " with Parser working on all 3 connectors by Mustafa Manya & Calvin Ng
* Implement & test class `Exe` by Calvin Ng
* General Testing and debug by Mustafa Manya & Calvin Ng











