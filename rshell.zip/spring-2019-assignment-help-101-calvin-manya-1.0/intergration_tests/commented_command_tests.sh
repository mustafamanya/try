#!../rshell


../rshell < "commented_command_test.txt"
