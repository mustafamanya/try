#!../rshell

../rshell < "singe_command_tests.txt"
