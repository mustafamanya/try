#!../rshell

../rshell < "exit_command_tests.txt"
