#!../rshell


../rshell < "multiple_commands_test.txt"

