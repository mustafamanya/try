#!../rshell

../rshell < "test_command_tests.txt"
